package sn.babs.l2gl_javafx_starter.controllers;

public class EmployeSceneController {
}
