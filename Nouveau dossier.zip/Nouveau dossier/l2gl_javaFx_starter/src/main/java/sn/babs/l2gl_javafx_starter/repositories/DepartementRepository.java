package sn.babs.l2gl_javafx_starter.repositories;

@Repository
public class DepartementRepository {
}
