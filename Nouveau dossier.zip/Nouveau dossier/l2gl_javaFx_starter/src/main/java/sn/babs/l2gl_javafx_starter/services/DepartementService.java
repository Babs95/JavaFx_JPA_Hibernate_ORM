package sn.babs.l2gl_javafx_starter.services;

import sn.babs.l2gl_javafx_starter.entities.Departement;
import sn.babs.l2gl_javafx_starter.utils.JPAUtils;

import jakarta.persistence.EntityManager;
import java.util.List;

public class DepartementService {
    public void createDepartement(Departement departement) {
        EntityManager entityManager = JPAUtils.getEntityManagerFactory().createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(departement);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public void updateDepartement(Departement departement) {
        EntityManager entityManager = JPAUtils.getEntityManagerFactory().createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.merge(departement);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public void deleteDepartement(Long id) {
        EntityManager entityManager = JPAUtils.getEntityManagerFactory().createEntityManager();
        entityManager.getTransaction().begin();
        Departement departement = entityManager.find(Departement.class, id);
        if(departement != null) {
            entityManager.remove(departement);
        }
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public List<Departement> getAllDepartements() {
        EntityManager entityManager = JPAUtils.getEntityManagerFactory().createEntityManager();
        List<Departement> departements = entityManager.createQuery("from Departement", Departement.class)
                .getResultList();
        entityManager.close();
        return departements;
    }
}
