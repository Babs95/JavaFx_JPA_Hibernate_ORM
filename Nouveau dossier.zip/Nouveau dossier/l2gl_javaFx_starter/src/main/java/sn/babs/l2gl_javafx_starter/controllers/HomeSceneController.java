package sn.babs.l2gl_javafx_starter.controllers;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class HomeSceneController {
    private Stage primaryStage;
    private Scene departementScene;
    private Scene employeScene;

    public void init(Stage primaryStage, Scene departementScene, Scene employeScene){
        this.primaryStage = primaryStage;
        this.departementScene = departementScene;
        this.employeScene = employeScene;
    }

    @FXML
    private Button btnDepartment;

    @FXML
    private Button btnEmployee;

    @FXML
    void openDepartementScene() {
        primaryStage.setScene(departementScene);
    }

    @FXML
    void openEmployeeScene() {
        primaryStage.setScene(employeScene);
    }
}
