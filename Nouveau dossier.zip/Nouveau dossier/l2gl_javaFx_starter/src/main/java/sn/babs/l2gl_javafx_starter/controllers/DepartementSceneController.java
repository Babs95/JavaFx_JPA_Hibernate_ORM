package sn.babs.l2gl_javafx_starter.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import sn.babs.l2gl_javafx_starter.entities.Departement;
import sn.babs.l2gl_javafx_starter.services.DepartementService;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class DepartementSceneController implements Initializable {
    @FXML
    private Button btnBack;

    @FXML
    private Button btnCancel;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnSave;

    @FXML
    private Button btnUpdate;

    @FXML
    private TextField inputLibelle;

    @FXML
    private TableView<Departement> tableDepartement;

    @FXML
    private TableColumn<Departement, Long> tableDepartementId;

    @FXML
    private TableColumn<Departement, String> tableDepartementLibelle;

    private Stage primaryStage;
    private Scene mainScene;

    private DepartementService departementService = new DepartementService();

    public void init(Stage primaryStage, Scene mainScene){
        this.primaryStage = primaryStage;
        this.mainScene = mainScene;
    }

    @FXML
    void backToMainScene() {
        primaryStage.setScene(mainScene);
    }

    @FXML
    void cancelOperation() {
        btnSave.setDisable(false);
        clearFields();
    }

    @FXML
    void createDepartement(ActionEvent event) {
        Departement departement = new Departement();
        departement.setLibelle(inputLibelle.getText());
        departementService.createDepartement(departement);
        loadTableDepartement();
        clearFields();
    }

    @FXML
    void deleteDepartement(ActionEvent event) {
        Departement selectedDepartement = tableDepartement.getSelectionModel().getSelectedItem();
        if(selectedDepartement != null) {
            departementService.deleteDepartement(selectedDepartement.getId());
            loadTableDepartement();
            cancelOperation();
        }
    }

    @FXML
    void updateDepartement(ActionEvent event) {
        Departement selectedDepartement = tableDepartement.getSelectionModel().getSelectedItem();
        if(selectedDepartement != null) {
            selectedDepartement.setLibelle(inputLibelle.getText());
            departementService.updateDepartement(selectedDepartement);
            loadTableDepartement();
            cancelOperation();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        tableDepartementId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableDepartementLibelle.setCellValueFactory(new PropertyValueFactory<>("libelle"));
        loadTableDepartement();
        tableDepartement.setOnMouseClicked(event -> handleTableClick(event));

    }

    private void loadTableDepartement() {
        tableDepartement.getItems().setAll(departementService.getAllDepartements());
    }

    private void clearFields() {
        inputLibelle.clear();
    }

    private void handleTableClick(MouseEvent event) {
        if(event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2) {
            btnSave.setDisable(true);
            Departement selectedDepartement = tableDepartement.getSelectionModel().getSelectedItem();
            if(selectedDepartement != null) inputLibelle.setText(selectedDepartement.getLibelle());
        }
    }
}
