package sn.babs.l2gl_javafx_starter;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import sn.babs.l2gl_javafx_starter.controllers.DepartementSceneController;
import sn.babs.l2gl_javafx_starter.controllers.HomeSceneController;

public class HelloApplication extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("L2IAGE EMPLOYE MANAGMENT");

        //Chargement de nos fichiers xml contenant nos interfaces
        FXMLLoader mainLoader = new FXMLLoader(getClass().getResource("/views/HomeScene.fxml"));
        Parent mainRoot = mainLoader.load();
        Scene mainScene = new Scene(mainRoot, 700, 500);

        FXMLLoader departementLoader = new FXMLLoader(getClass().getResource("/views/DepartementScene.fxml"));
        Parent departementRoot = departementLoader.load();
        Scene departementScene = new Scene(departementRoot, 700, 500);

        FXMLLoader employeLoader = new FXMLLoader(getClass().getResource("/views/EmployeScene.fxml"));
        Parent employeRoot = employeLoader.load();
        Scene employScene = new Scene(employeRoot, 700, 500);

        //Initialisation des controlleurs
        HomeSceneController homeSceneController = mainLoader.getController();
        homeSceneController.init(primaryStage, departementScene, employScene);

        DepartementSceneController departementSceneController = departementLoader.getController();
        departementSceneController.init(primaryStage, mainScene);

        primaryStage.setScene(mainScene);
        primaryStage.show();
    }
}