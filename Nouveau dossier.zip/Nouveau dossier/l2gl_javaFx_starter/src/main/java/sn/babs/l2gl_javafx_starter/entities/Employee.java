package sn.babs.l2gl_javafx_starter.entities;

import jakarta.persistence.*;

@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String nom;
    private String prenom;
    @ManyToOne
    @JoinColumn(name = "departement_id")
    private Departement departement;
}
