module sn.babs.l2gl_javafx_starter {
    requires javafx.controls;
    requires javafx.fxml;
    requires jakarta.persistence;
    requires org.hibernate.orm.core;
    requires java.sql;


    opens sn.babs.l2gl_javafx_starter to javafx.fxml;
    opens sn.babs.l2gl_javafx_starter.controllers to javafx.fxml;
    opens sn.babs.l2gl_javafx_starter.entities to org.hibernate.orm.core;

    exports sn.babs.l2gl_javafx_starter;
    exports sn.babs.l2gl_javafx_starter.entities;
    exports sn.babs.l2gl_javafx_starter.controllers;
}