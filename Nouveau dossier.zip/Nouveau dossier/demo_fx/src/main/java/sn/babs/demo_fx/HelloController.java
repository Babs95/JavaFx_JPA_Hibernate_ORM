package sn.babs.demo_fx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {

    @FXML
    private Label welcomeText;

    @FXML
    private Button logoutButton;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Bienvenue dans votre système de gestion d'épicerie!");
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            // Retourner à la page de login
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login-view.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 350, 400);

            stage.setScene(scene);
            stage.setTitle("Connexion - Demo Application");
            stage.setResizable(false);
            stage.show();

        } catch (IOException e) {
            showAlert("Erreur", "Impossible de retourner à la page de connexion.");
            e.printStackTrace();
        }
    }

    @FXML
    private void handleProductManagement(MouseEvent event) {
        try {
            // Naviguer vers la page de gestion des produits
            FXMLLoader loader = new FXMLLoader(getClass().getResource("product-management-view.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 1000, 700);

            stage.setScene(scene);
            stage.setTitle("EpicerieApp - Gestion des Produits");
            stage.show();

        } catch (IOException e) {
            showAlert("Erreur", "Impossible de charger la page de gestion des produits.");
            e.printStackTrace();
        }
    }

    @FXML
    private void handlePointOfSale(MouseEvent event) {
        showAlert("Point de Vente", "Module de point de vente en cours de développement...");
    }

    @FXML
    private void handleStockManagement(MouseEvent event) {
        showAlert("Gestion du Stock", "Module de gestion du stock en cours de développement...");
    }

    @FXML
    private void handleReports(MouseEvent event) {
        showAlert("Rapports", "Module de rapports en cours de développement...");
    }

    @FXML
    private void handleSuppliers(MouseEvent event) {
        showAlert("Fournisseurs", "Module de gestion des fournisseurs en cours de développement...");
    }

    @FXML
    private void handleSettings(MouseEvent event) {
        showAlert("Paramètres", "Module de paramètres en cours de développement...");
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}