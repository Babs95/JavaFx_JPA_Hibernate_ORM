package sn.babs.demo_fx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    @FXML
    private Button loginButton;

    // Identifiants de connexion valides
    private static final String VALID_EMAIL = "test@yopmail.com";
    private static final String VALID_PASSWORD = "passer@123";

    @FXML
    private void handleLogin(ActionEvent event) {
        String email = emailField.getText().trim();
        String password = passwordField.getText();

        // Réinitialiser le message d'erreur
        errorLabel.setVisible(false);

        // Validation des champs
        if (email.isEmpty() || password.isEmpty()) {
            showError("Veuillez remplir tous les champs.");
            return;
        }

        // Vérification des identifiants
        if (VALID_EMAIL.equals(email) && VALID_PASSWORD.equals(password)) {
            // Connexion réussie - naviguer vers HelloApplication
            try {
                navigateToHelloApplication(event);
            } catch (IOException e) {
                showError("Erreur lors du chargement de la page principale.");
                e.printStackTrace();
            }
        } else {
            showError("Email ou mot de passe incorrect.");
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }

    private void navigateToHelloApplication(ActionEvent event) throws IOException {
        // Charger la vue HelloApplication
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();

        // Obtenir la scène actuelle
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Créer une nouvelle scène
        Scene scene = new Scene(root);

        // Changer de scène
        stage.setScene(scene);
        stage.setTitle("Hello Application");
        stage.show();
    }

    @FXML
    private void initialize() {
        // Permettre la connexion avec la touche Entrée
        emailField.setOnAction(e -> passwordField.requestFocus());
        passwordField.setOnAction(e -> handleLogin(new ActionEvent()));
    }
}
