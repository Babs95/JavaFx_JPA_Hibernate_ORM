package sn.babs.demo_fx;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ProductManagementController implements Initializable {

    // Formulaire
    @FXML private TextField productNameField;
    @FXML private TextField productPriceField;
    @FXML private TextField productQuantityField;
    @FXML private ComboBox<String> categoryComboBox;
    @FXML private TextArea productDescriptionArea;

    // Boutons
    @FXML private Button backButton;
    @FXML private Button addProductButton;
    @FXML private Button updateProductButton;
    @FXML private Button clearFormButton;
    @FXML private Button searchButton;

    // Recherche
    @FXML private TextField searchField;

    // Table
    @FXML private TableView<Product> productsTable;
    @FXML private TableColumn<Product, String> nameColumn;
    @FXML private TableColumn<Product, Double> priceColumn;
    @FXML private TableColumn<Product, Integer> quantityColumn;
    @FXML private TableColumn<Product, String> categoryColumn;
    @FXML private TableColumn<Product, Void> actionColumn;

    // Données
    private ObservableList<Product> productsList = FXCollections.observableArrayList();
    private Product selectedProduct = null;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setupCategories();
        setupTable();
        loadSampleData();
    }

    private void setupCategories() {
        categoryComboBox.setItems(FXCollections.observableArrayList(
                "Épicerie", "Fruits & Légumes", "Produits Laitiers",
                "Boulangerie", "Boissons", "Hygiène", "Autre"
        ));
    }

    private void setupTable() {
        // Configuration des colonnes
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));

        // Formatage des prix
        priceColumn.setCellFactory(col -> new TableCell<Product, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("%.0f FCFA", price));
                }
            }
        });

        // Colonne d'actions
        actionColumn.setCellFactory(col -> new TableCell<Product, Void>() {
            private final Button editButton = new Button("✏️");
            private final Button deleteButton = new Button("🗑️");

            {
                editButton.setStyle("-fx-background-color: #f39c12; -fx-text-fill: white; -fx-background-radius: 3;");
                deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-background-radius: 3;");

                editButton.setOnAction(e -> editProduct(getTableView().getItems().get(getIndex())));
                deleteButton.setOnAction(e -> deleteProduct(getTableView().getItems().get(getIndex())));
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox buttons = new HBox(5, editButton, deleteButton);
                    setGraphic(buttons);
                }
            }
        });

        // Associer les données à la table
        productsTable.setItems(productsList);
    }

    private void loadSampleData() {
        productsList.addAll(
                new Product("Riz Brisure", 1500, 50, "Épicerie", "Riz brisure 25kg"),
                new Product("Lait en Poudre", 2500, 30, "Produits Laitiers", "Lait en poudre 1kg"),
                new Product("Pommes", 800, 15, "Fruits & Légumes", "Pommes rouges 1kg"),
                new Product("Pain de Mie", 650, 25, "Boulangerie", "Pain de mie complet"),
                new Product("Coca Cola", 300, 100, "Boissons", "Coca Cola 33cl")
        );
    }

    // Actions des boutons
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 800, 700);

            stage.setScene(scene);
            stage.setTitle("EpicerieApp - Accueil");
            stage.show();

        } catch (IOException e) {
            showAlert("Erreur", "Impossible de retourner à l'accueil.");
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAddProduct() {
        if (validateForm()) {
            Product newProduct = new Product(
                    productNameField.getText().trim(),
                    Double.parseDouble(productPriceField.getText()),
                    Integer.parseInt(productQuantityField.getText()),
                    categoryComboBox.getValue(),
                    productDescriptionArea.getText().trim()
            );

            productsList.add(newProduct);
            clearForm();
            showAlert("Succès", "Produit ajouté avec succès !");
        }
    }

    @FXML
    private void handleUpdateProduct() {
        if (selectedProduct != null && validateForm()) {
            selectedProduct.setName(productNameField.getText().trim());
            selectedProduct.setPrice(Double.parseDouble(productPriceField.getText()));
            selectedProduct.setQuantity(Integer.parseInt(productQuantityField.getText()));
            selectedProduct.setCategory(categoryComboBox.getValue());
            selectedProduct.setDescription(productDescriptionArea.getText().trim());

            productsTable.refresh();
            clearForm();
            showAlert("Succès", "Produit modifié avec succès !");
        }
    }

    @FXML
    private void handleClearForm() {
        clearForm();
    }

    @FXML
    private void handleSearch() {
        String searchTerm = searchField.getText().toLowerCase().trim();
        if (searchTerm.isEmpty()) {
            productsTable.setItems(productsList);
        } else {
            ObservableList<Product> filteredList = productsList.filtered(product ->
                    product.getName().toLowerCase().contains(searchTerm) ||
                            product.getCategory().toLowerCase().contains(searchTerm)
            );
            productsTable.setItems(filteredList);
        }
    }

    // Méthodes privées
    private void editProduct(Product product) {
        selectedProduct = product;
        productNameField.setText(product.getName());
        productPriceField.setText(String.valueOf(product.getPrice()));
        productQuantityField.setText(String.valueOf(product.getQuantity()));
        categoryComboBox.setValue(product.getCategory());
        productDescriptionArea.setText(product.getDescription());

        addProductButton.setVisible(false);
        updateProductButton.setVisible(true);
    }

    private void deleteProduct(Product product) {
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Confirmation");
        confirmAlert.setHeaderText("Supprimer le produit");
        confirmAlert.setContentText("Êtes-vous sûr de vouloir supprimer \"" + product.getName() + "\" ?");

        if (confirmAlert.showAndWait().get() == ButtonType.OK) {
            productsList.remove(product);
            showAlert("Succès", "Produit supprimé avec succès !");
        }
    }

    private boolean validateForm() {
        if (productNameField.getText().trim().isEmpty()) {
            showAlert("Erreur", "Le nom du produit est obligatoire.");
            return false;
        }

        try {
            double price = Double.parseDouble(productPriceField.getText());
            if (price < 0) {
                showAlert("Erreur", "Le prix doit être positif.");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert("Erreur", "Le prix doit être un nombre valide.");
            return false;
        }

        try {
            int quantity = Integer.parseInt(productQuantityField.getText());
            if (quantity < 0) {
                showAlert("Erreur", "La quantité doit être positive.");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert("Erreur", "La quantité doit être un nombre entier valide.");
            return false;
        }

        if (categoryComboBox.getValue() == null) {
            showAlert("Erreur", "Veuillez sélectionner une catégorie.");
            return false;
        }

        return true;
    }

    private void clearForm() {
        productNameField.clear();
        productPriceField.clear();
        productQuantityField.clear();
        categoryComboBox.setValue(null);
        productDescriptionArea.clear();

        selectedProduct = null;
        addProductButton.setVisible(true);
        updateProductButton.setVisible(false);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Classe Product
    public static class Product {
        private final SimpleStringProperty name;
        private final SimpleDoubleProperty price;
        private final SimpleIntegerProperty quantity;
        private final SimpleStringProperty category;
        private final SimpleStringProperty description;

        public Product(String name, double price, int quantity, String category, String description) {
            this.name = new SimpleStringProperty(name);
            this.price = new SimpleDoubleProperty(price);
            this.quantity = new SimpleIntegerProperty(quantity);
            this.category = new SimpleStringProperty(category);
            this.description = new SimpleStringProperty(description);
        }

        // Getters
        public String getName() { return name.get(); }
        public double getPrice() { return price.get(); }
        public int getQuantity() { return quantity.get(); }
        public String getCategory() { return category.get(); }
        public String getDescription() { return description.get(); }

        // Setters
        public void setName(String name) { this.name.set(name); }
        public void setPrice(double price) { this.price.set(price); }
        public void setQuantity(int quantity) { this.quantity.set(quantity); }
        public void setCategory(String category) { this.category.set(category); }
        public void setDescription(String description) { this.description.set(description); }

        // Property getters (pour TableView)
        public SimpleStringProperty nameProperty() { return name; }
        public SimpleDoubleProperty priceProperty() { return price; }
        public SimpleIntegerProperty quantityProperty() { return quantity; }
        public SimpleStringProperty categoryProperty() { return category; }
        public SimpleStringProperty descriptionProperty() { return description; }
    }
}