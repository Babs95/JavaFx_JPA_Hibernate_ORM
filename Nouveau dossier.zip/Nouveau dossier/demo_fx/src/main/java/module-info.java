module sn.babs.demo_fx {
    requires javafx.controls;
    requires javafx.fxml;


    opens sn.babs.demo_fx to javafx.fxml;
    exports sn.babs.demo_fx;
}